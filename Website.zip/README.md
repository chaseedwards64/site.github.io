## TODO

- About - 
    - kind
    - logical
    - creative
    - trustworthy
    - compassionate
    - understanding
    - optimistic
    - empathetic
    - thoughtful
    - responsible
    - caring
    - calm
    - genuine
    - selfles
    - hard working
    - loyal
    - mature

    - Programming
    - Music - Piano
    - Art
    - Reading
    - Gaming
    - 
    - 

Skills
Education
Work
Experience
Contact